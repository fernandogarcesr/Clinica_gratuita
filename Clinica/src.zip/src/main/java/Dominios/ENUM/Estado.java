/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package Dominios.ENUM;

/**
 *
 * Clase para determinar el dominio sobre el estado de la cita
 */
public enum Estado {
    PROGRAMADA,
    ENCURSO,
    COMPLETADA,
    CANCELADA

}
