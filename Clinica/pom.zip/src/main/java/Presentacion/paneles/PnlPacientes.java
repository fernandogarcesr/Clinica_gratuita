package Presentacion.paneles;

import BO.PacienteBO;
import DTO.PacienteDTO;
import Dominios.PacienteDominio;
import Presentacion.dialogs.registro.DlgRegistrarPaciente;
import Presentacion.paneles.elementos.PnlElementoPaciente;
import Presentacion.styles.*;

import java.util.List;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PnlPacientes extends JPanel{
    private PacienteBO pacienteBO;
    private JTable tblPacientes;
    Style style = new Style();
    boolean testeoColor = false;
    PnlPacientes pnlPacientes = this;

    //Título
    ContainerPanel titulo = new ContainerPanel(style.frameX, 40, Color.RED, testeoColor);
    CustomLabel lblTitulo = new CustomLabel("           Pacientes", 24);

    //Columnas
    ContainerPanel columnas = new ContainerPanel(style.frameX, 50, Color.BLUE, false);
    CustomLabel lblNombre = new CustomLabel("Nombre", style.letraSize);
    CustomLabel lblSexo = new CustomLabel("Sexo", style.letraSize);
    CustomLabel lblEdad = new CustomLabel("Edad", style.letraSize);
    CustomLabel lblTelefono = new CustomLabel("Teléfono", style.letraSize);

    //Botón
    CustomButton btnRegistrarPaciente = new CustomButton("Registrar nuevo paciente");

    //Espaciadores
    Espaciador espaciov1 = new Espaciador(10, 30);

    int espacioX = 100;
    Espaciador espacioh1 = new Espaciador(300, 10);
    Espaciador espacioh2 = new Espaciador(10, 10);
    Espaciador espacioh3 = new Espaciador(80, 10);


    public PnlPacientes() {

        this.pacienteBO = pacienteBO;
        reloadPacientes();
        
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        add(espaciov1);

        //Encabezado
        titulo.setLayout(new BorderLayout());
        titulo.add(lblTitulo, BorderLayout.WEST);
        add(titulo);

        columnas.setLayout(new GridLayout(1,6));

        columnas.add(espacioh1);
        columnas.add(lblNombre);
        columnas.add(lblSexo);
        columnas.add(lblEdad);
        columnas.add(lblTelefono);

        add(columnas);


        //----------PLACEHOLDER HARDCODEADO----------
        PnlElementoPaciente ejemplo = new PnlElementoPaciente(pnlPacientes);
        add(ejemplo);
        //----------FIN DE PLACEHOLDER----------


        //----------LÓGICA AQUÍ----------
        /*

        for(int i = 0; i < pacientes.length; i++){
            PnlElementoPaciente elementoPaciente = new PnlElementoPaciente(pnlPacientes, paciente);
            add(elementoPaciente)
        }

         */
        //----------FIN DE LÓGICA----------


            btnRegistrarPaciente.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    DlgRegistrarPaciente registrar = new DlgRegistrarPaciente(null, pnlPacientes, pacienteBO);
                    registrar.setVisible(true);
                }
            });
        add(btnRegistrarPaciente);

        setOpaque(false);
        setVisible(true);
    }
    
     public void reloadPacientes() {
        try {
            List<PacienteDominio> lista = pacienteBO.listarPacientes();
            // Convertir a modelo de tabla (ejemplo simple)
            String[] columnas = {"ID", "Nombre", "Apellido Paterno", "Apellido Materno", "Edad", "Sexo", "Teléfono", "Email"};
            Object[][] data = new Object[lista.size()][columnas.length];
            for (int i = 0; i < lista.size(); i++) {
                PacienteDominio p = lista.get(i);
                data[i][0] = p.getId_paciente();
                data[i][1] = p.getNombre();
                data[i][2] = p.getApellidoPaterno();
                data[i][3] = p.getApellidoMaterno();
                data[i][4] = p.getEdad();
                data[i][5] = p.getSexo();
                data[i][6] = p.getTelefono();
                data[i][7] = p.getEmail();
            }
            tblPacientes.setModel(new javax.swing.table.DefaultTableModel(data, columnas) {
                @Override public boolean isCellEditable(int row, int column) { return false; }
            });
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Error cargando pacientes: " + e.getMessage(), "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }

    public void refresh() {

        System.out.println("refresh pnlPacientes");

        revalidate();
        repaint();
    }
}
