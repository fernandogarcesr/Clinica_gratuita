/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package Dominios.ENUM;

/**
 *
 * Clase usada para determinar el dominio sobre los generos que hay
 */
public enum Sexo {
    MASCULINO,
    FEMENINO
}
